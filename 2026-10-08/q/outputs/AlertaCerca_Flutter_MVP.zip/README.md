# ALERTA CERCA - MVP Flutter

Starter para la API de ASP.NET Core y SQL Server que definimos.

## Incluye

- Solicita ubicación en primer plano solo cuando la persona actualiza alertas o envía un reporte.
- Consulta alertas verificadas con GET /api/alertas/cercanas.
- Envía reportes con POST /api/reportes.
- Muestra categoría, distancia y detalles de cada alerta.
- Aún no incluye notificaciones push, inicio de sesión ni funciones de moderador.

## Crear el proyecto Flutter

~~~powershell
flutter create alerta_cerca
~~~

Copia la carpeta lib de este paquete en el proyecto nuevo. Copia también
pubspec.yaml a la raíz y ejecuta:

~~~powershell
flutter pub get
~~~

## Dirección de la API

Ejecuta la API ASP.NET Core en el puerto 5080 y configura Flutter con la dirección correspondiente.

Emulador Android:

~~~powershell
flutter run --dart-define=ALERTA_API_URL=http://10.0.2.2:5080
~~~

Teléfono Android conectado al mismo Wi-Fi que la computadora de la API:

~~~powershell
flutter run --dart-define=ALERTA_API_URL=http://192.168.1.20:5080
~~~

Reemplaza 192.168.1.20 con la dirección IPv4 local de tu computadora. Ambos
dispositivos deben estar en la misma red y el firewall debe permitir el puerto
de la API en la red privada.

## Permisos para Android

Agrega estos permisos directamente debajo de <manifest> en
android/app/src/main/AndroidManifest.xml:

~~~xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
~~~

Solo para desarrollo local por HTTP, agrega
android:usesCleartextTraffic="true" al elemento <application>. Retíralo
cuando uses una API HTTPS en producción.

## Permiso de ubicación para iOS

Agrega esto a ios/Runner/Info.plist:

~~~xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>ALERTA CERCA usa tu ubicación mientras consultas o reportas una situación.</string>
~~~

Para compilar y ejecutar en iOS se necesitan macOS y Xcode.

## Contrato esperado de la API

POST /api/reportes recibe:

~~~json
{
  "categoria": "INUNDACION",
  "titulo": "Reporte de prueba",
  "descripcion": "Datos ficticios para la demostración",
  "latitud": 17.95,
  "longitud": -102.2
}
~~~

Debe responder HTTP 201 con un JSON que incluya id.

La app consulta:

GET /api/alertas/cercanas?lat=17.95&lon=-102.2&radioMetros=3000

Debe responder HTTP 200 con una lista JSON. Cada elemento debe incluir
alertaId, categoria, titulo, descripcion, estado, creadaUtc, latitud, longitud
y distanciaMetros. El modelo Dart acepta nombres JSON en camelCase o PascalCase.
