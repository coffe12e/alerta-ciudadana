import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/alerta.dart';

class AlertaApi {
  AlertaApi({http.Client? client}) : _client = client ?? http.Client();

  static const String baseUrl = String.fromEnvironment(
    'ALERTA_API_URL',
    defaultValue: 'http://10.0.2.2:5080',
  );

  final http.Client _client;

  Future<List<Alerta>> obtenerCercanas({
    required double latitud,
    required double longitud,
    required int radioMetros,
  }) async {
    final uri = Uri.parse('$baseUrl/api/alertas/cercanas').replace(
      queryParameters: {
        'lat': latitud.toString(),
        'lon': longitud.toString(),
        'radioMetros': radioMetros.toString(),
      },
    );

    final response = await _client
        .get(uri, headers: const {'Accept': 'application/json'})
        .timeout(const Duration(seconds: 15));

    if (response.statusCode != 200) {
      throw Exception(_mensajeError(response));
    }

    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! List) {
      throw Exception('La API respondió con un formato inesperado.');
    }

    return decoded
        .whereType<Map<String, dynamic>>()
        .map(Alerta.fromJson)
        .toList();
  }

  Future<int> crearReporte(NuevoReporte reporte) async {
    final uri = Uri.parse('$baseUrl/api/reportes');
    final response = await _client
        .post(
          uri,
          headers: const {
            'Accept': 'application/json',
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonEncode(reporte.toJson()),
        )
        .timeout(const Duration(seconds: 15));

    if (response.statusCode != 201) {
      throw Exception(_mensajeError(response));
    }

    final decoded =
        jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final id = decoded['id'];
    if (id is int) return id;
    return int.tryParse(id?.toString() ?? '') ?? 0;
  }

  String _mensajeError(http.Response response) {
    try {
      final decoded =
          jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      final message = decoded['error']?.toString();
      if (message != null && message.isNotEmpty) return message;
    } catch (_) {
      // El servidor quizá devolvió una respuesta que no es JSON.
    }
    return 'Error HTTP ${response.statusCode} al comunicarse con la API.';
  }

  void dispose() => _client.close();
}
