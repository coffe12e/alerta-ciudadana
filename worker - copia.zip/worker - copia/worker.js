import { createClient } from '@supabase/supabase-js'

// La service_role key SOLO va aquí, nunca en la app ni en GitHub
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SERVICE_ROLE_KEY
)

// B1 puede reemplazar esto por el envío real con Firebase Cloud Messaging
async function enviarPush(aviso) {
  console.log('--------------------------------')
  console.log('Usuario:   ', aviso.usuario_id)
  console.log('Categoría: ', aviso.categoria)
  console.log('Nivel:     ', aviso.nivel)
  console.log('Distancia: ', aviso.distancia_m, 'm')
  console.log('Estado:    ', aviso.verificacion)
  console.log('Radio:     ', aviso.radio_actual_m, 'm')
}

async function avisarAlerta(alertaId) {
  const { data: avisos, error } = await supabase.rpc('usuarios_a_avisar', {
    p_alerta_id: alertaId,
  })
  if (error) return console.error('usuarios_a_avisar', error)

  for (const aviso of avisos ?? []) {
    await enviarPush(aviso)
    await supabase.from('notificaciones').upsert(
      {
        alerta_id: alertaId,
        usuario_id: aviso.usuario_id,
        distancia_m: aviso.distancia_m,
        ronda: aviso.ronda,
      },
      { onConflict: 'alerta_id,usuario_id', ignoreDuplicates: true }
    )
  }
}

async function ciclo() {
 console.log('Ciclo', new Date().toLocaleTimeString())
  await supabase.rpc('expirar_alertas')
  await supabase.rpc('procesar_alertas_pendientes')
  await supabase.rpc('expandir_radios')

  const { data: activas } = await supabase
    .from('alertas').select('id').eq('estado', 'activa')
  for (const a of activas ?? []) await avisarAlerta(a.id)
}

// Cada 10 segundos para la demo (sube a 60_000 para uso normal)
setInterval(() => ciclo().catch(console.error), 10_000)
ciclo()